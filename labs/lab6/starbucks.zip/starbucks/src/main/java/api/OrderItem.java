package api ;

class OrderItem {

    public int qty ;
    public String name ;
    public String milk ;
    public String size ;

}